<?php
session_start();
unset($_SESSION["username"]);
?>
<script type="text/javascript">
    window.location="student_login.php";
</script>
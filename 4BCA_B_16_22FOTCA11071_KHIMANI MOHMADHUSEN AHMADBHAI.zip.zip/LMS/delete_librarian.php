<?php
session_start();
if(!isset($_SESSION["admin"]))
{
    ?>
    <script type="text/javascript">
        window.location="admin_login.php";
    </script>
    <?php
}
include "connection.php";
if(isset($_GET["id"]))
{
    $id = $_GET["id"];
    mysqli_query($link,"delete from librarian_registration where id=$id");
?>

<script type="text/javascript">
        window.location="display_librarian_info.php";
    </script>
<?php
}
else
{
    ?>
    <script type="text/javascript">
        window.location="display_librarian_info.php";
    </script>
    <?php
}
?>
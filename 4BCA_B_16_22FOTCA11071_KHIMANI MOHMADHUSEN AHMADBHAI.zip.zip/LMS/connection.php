<?php
$link = mysqli_connect("sql213.infinityfree.com","if0_35918567","JkMPvlO0Ac1MLdK");
mysqli_select_db($link,"if0_35918567_if0_35918567_lms");
?>
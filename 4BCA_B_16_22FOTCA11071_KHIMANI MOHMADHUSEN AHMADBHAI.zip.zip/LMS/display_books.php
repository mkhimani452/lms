<?php
session_start();
if(!isset($_SESSION["librarian"]))
{
    ?>
    <script type="text/javascript">
        window.location="librarian_login.php";
    </script>
    <?php
}
include "connection.php";
//include "librarian_header.php";


$tot=0;
$res = mysqli_query($link,"select * from librarian_massages where dusername='$_SESSION[librarian]' && read1='n'");
$tot=mysqli_num_rows($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Display Books</title>


    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/nprogress.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="#" class="site_title"><i class="fa fa-book"></i> <span>LMS</span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                        <img src="images/img.jpg" alt="..." class="img-circle profile_img">
                    </div>
                    <div class="profile_info">
                        <span>Welcome,</span>
                        <h2><?php echo $_SESSION["librarian"]; ?></h2>
                    </div>

                    <div class="clearfix"></div>
                </div>
                <!-- /menu profile quick info -->

                <br/>

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <h3>General</h3>
                        <ul class="nav side-menu">
                            <li><a href="display_student_info.php"><i class="fa fa-home"></i> All Student Info <span class="fa fa-chevron-down"></span></a>


                            </li>
                            <li><a href="add_books.php"><i class="fa fa-edit"></i> Add Books <span class="fa fa-chevron-down"></span></a>


                            </li>
                            <li><a href="display_books.php"><i class="fa fa-desktop"></i> Display Books <span
                                    class="fa fa-chevron-down"></span></a>
                            </li>
                            <li><a href="issue_books.php"><i class="fa fa-table"></i> Issue Books <span class="fa fa-chevron-down"></span></a>


                            </li>
                            <li><a href="return_book.php"><i class="fa fa-bar-chart-o"></i> Returns Books <span
                                    class="fa fa-chevron-down"></span></a>


                            </li>
                            <li><a href="books_details_with_student.php"><i class="fa fa-bar-chart-o"></i> Books With All Info<span
                                    class="fa fa-chevron-down"></span></a>


                            </li>
                            <li><a href="send_notification_student.php"><i class="fa fa-mail-forward"></i> SendMassage Student<span
                                    class="fa fa-chevron-down"></span></a>


                            </li>


                        </ul>
                    </div>




                </div>


            </div>
        </div>


        <!-- top navigation -->

        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                    </div>


                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown"
                               aria-expanded="false">
                                <img src="images/img.jpg" alt=""><?php echo $_SESSION["librarian"]; ?>
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="librarian_logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>
                        
                        <li role="presentation" class="dropdown">
                            <a href="massage_from_admin.php" class="dropdown-toggle info-number" data-toggle="dropdown"
                               aria-expanded="false">
                                <i class="fa fa-bell-o"></i>
                                <span class="badge bg-green" onclick="window.location='massage_from_admin.php'"><?php echo $tot; ?></span>
                            </a>

                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->


       <!-- page content area main -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3></h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <!-- <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                    </div> -->
                </div>
            </div>
        </div>

        <div class="clearfix"></div>
        <div class="row" style="min-height:500px">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Display Books</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form name="form1" action="" method="post">
                            <input type="text" name="t1" class="form-control" placeholder="Enter Books Name">
                            <input type="submit" name="submit1" value="Search Book" class="btn btn-default">
                        </form>
                        <div class="table-responsive"> <!-- Wrap the table with this div -->
                            <?php
                            if(isset($_POST["submit1"]))
                            {
                                $res = mysqli_query($link,"select * from add_books where books_name like('$_POST[t1]%')");
                                echo "<table class='table table-bordered'>";
                                // Table headers
                                echo "<tr>";
                                echo "<th>"; echo "Books Name"; echo "</th>";
                                echo "<th>"; echo "Books Image"; echo "</th>";
                                echo "<th>"; echo "Books Author Name"; echo "</th>";
                                echo "<th>"; echo "Books Publication Name"; echo "</th>";
                                echo "<th>"; echo "Books Purchase Date"; echo "</th>";
                                echo "<th>"; echo "Books Price"; echo "</th>";
                                echo "<th>"; echo "Books Quantity"; echo "</th>";
                                echo "<th>"; echo "Available Quantity"; echo "</th>";
                                echo "<th>"; echo "Delete Books"; echo "</th>";
                                echo "</tr>";
                                // Table rows
                                while($row = mysqli_fetch_array($res)){
                                    echo "<tr>";
                                    echo "<td>"; echo $row["books_name"]; echo "</td>";
                                    echo "<td>"; ?> <img src="<?php echo $row["books_image"]; ?>" alt="" height="100" width="100"> <?php echo "</td>";
                                    echo "<td>"; echo $row["books_author_name"]; echo "</td>";
                                    echo "<td>"; echo $row["books_publication_name"]; echo "</td>";
                                    echo "<td>"; echo $row["books_purchase_date"]; echo "</td>";
                                    echo "<td>"; echo $row["books_price"]; echo "</td>";
                                    echo "<td>"; echo $row["books_qty"]; echo "</td>";
                                    echo "<td>"; echo $row["available_qty"]; echo "</td>";
                                    echo "<td>"; ?> <a href="delete_books.php?id=<?php echo $row["id"]; ?>">Delete Books</a> <?php echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</table>";
                            }
                            else
                            {
                                $res = mysqli_query($link,"select * from add_books");
                                echo "<table class='table table-bordered'>";
                                // Table headers
                                echo "<tr>";
                                echo "<th>"; echo "Books Name"; echo "</th>";
                                echo "<th>"; echo "Books Image"; echo "</th>";
                                echo "<th>"; echo "Books Author Name"; echo "</th>";
                                echo "<th>"; echo "Books Publication Name"; echo "</th>";
                                echo "<th>"; echo "Books Purchase Date"; echo "</th>";
                                echo "<th>"; echo "Books Price"; echo "</th>";
                                echo "<th>"; echo "Books Quantity"; echo "</th>";
                                echo "<th>"; echo "Available Quantity"; echo "</th>";
                                echo "<th>"; echo "Delete Books"; echo "</th>";
                                echo "</tr>";
                                // Table rows
                                while($row = mysqli_fetch_array($res)){
                                    echo "<tr>";
                                    echo "<td>"; echo $row["books_name"]; echo "</td>";
                                    echo "<td>"; ?> <img src="<?php echo $row["books_image"]; ?>" alt="" height="100" width="100"> <?php echo "</td>";
                                    echo "<td>"; echo $row["books_author_name"]; echo "</td>";
                                    echo "<td>"; echo $row["books_publication_name"]; echo "</td>";
                                    echo "<td>"; echo $row["books_purchase_date"]; echo "</td>";
                                    echo "<td>"; echo $row["books_price"]; echo "</td>";
                                    echo "<td>"; echo $row["books_qty"]; echo "</td>";
                                    echo "<td>"; echo $row["available_qty"]; echo "</td>";
                                    echo "<td>"; ?> <a href="delete_books.php?id=<?php echo $row["id"]; ?>">Delete Books</a> <?php echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</table>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->


<?php
include "librarian_footer.php";
?>
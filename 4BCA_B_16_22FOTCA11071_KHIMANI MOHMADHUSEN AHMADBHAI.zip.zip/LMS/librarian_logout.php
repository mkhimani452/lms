<?php
session_start();
unset($_SESSION["librarian"]);
?>
<script type="text/javascript">
    window.location="librarian_login.php";
</script>